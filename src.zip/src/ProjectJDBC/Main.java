package ProjectJDBC;

import java.sql.Timestamp;

public class Main {

	public static void main(String[] args) {

        // ---------------- SHIP ----------------

        Ship ship = new Ship();

        ship.setShipName("Ocean King");

        ship.setShipType("Cargo");

        ship.setCapacity(50000);

        ship.setOwnerCompany("BlueWave Logistics");

        ship.setStatus("ACTIVE");

        ShipDAO shipDAO =
        new ShipDAO();

        shipDAO.addShip(ship);

        // ---------------- PORT ----------------

        Port port = new Port();

        port.setPortName("Mumbai Port");

        port.setCountry("India");

        port.setCity("Mumbai");

        PortDAO portDAO =
        new PortDAO();

        portDAO.addPort(port);

        // ---------------- VOYAGE ----------------

        Voyage voyage =
        new Voyage();

        voyage.setShipId(1);

        voyage.setSourcePortId(1);

        voyage.setDestinationPortId(2);

        voyage.setDepartureTime(
        new Timestamp(System.currentTimeMillis())
        );

        voyage.setArrivalTime(
        new Timestamp(System.currentTimeMillis()
        + (5L * 24 * 60 * 60 * 1000))
        );

        voyage.setCargoWeight(25000);

        voyage.setStatus("IN_TRANSIT");

        VoyageDAO voyageDAO =
        new VoyageDAO();

        voyageDAO.createVoyage(voyage);

        // ---------------- VIEW VOYAGES ----------------

        voyageDAO.viewVoyages();
    }
}
