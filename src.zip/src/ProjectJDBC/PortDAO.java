package ProjectJDBC;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class PortDAO {

	public void addPort(Port port) {

        String query =
        "INSERT INTO ports(port_name,country,city) VALUES(?,?,?)";

        try(
            Connection con =
            DBConnection.getConnection();

            PreparedStatement ps =
            con.prepareStatement(query);
        ) {

            ps.setString(1, port.getPortName());

            ps.setString(2, port.getCountry());

            ps.setString(3, port.getCity());

            ps.executeUpdate();

            System.out.println(
            "Port Added Successfully"
            );

        } catch(Exception e) {

            e.printStackTrace();
        }
    }

    // VIEW PORTS
    public void viewPorts() {

        String query =
        "SELECT * FROM ports";

        try(
            Connection con =
            DBConnection.getConnection();

            PreparedStatement ps =
            con.prepareStatement(query);

            ResultSet rs =
            ps.executeQuery();
        ) {

            while(rs.next()) {

                System.out.println(
                    rs.getInt("port_id") + " " +
                    rs.getString("port_name") + " " +
                    rs.getString("country") + " " +
                    rs.getString("city")
                );
            }

        } catch(Exception e) {

            e.printStackTrace();
        }
    }
	
}
