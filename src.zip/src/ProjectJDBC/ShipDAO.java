package ProjectJDBC;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class ShipDAO {
	
	 public void addShip(Ship ship) {

	        String query =
	        "INSERT INTO ships(ship_name, ship_type, capacity, owner_company, status) VALUES(?,?,?,?,?)";

	        try(
	            Connection con =
	            DBConnection.getConnection();

	            PreparedStatement ps =
	            con.prepareStatement(query);
	        ) {

	            ps.setString(1, ship.getShipName());

	            ps.setString(2, ship.getShipType());

	            ps.setInt(3, ship.getCapacity());

	            ps.setString(4, ship.getOwnerCompany());

	            ps.setString(5, ship.getStatus());

	            int rows =
	            ps.executeUpdate();

	            System.out.println(
	            rows + " Ship Added Successfully"
	            );

	        } catch(Exception e) {

	            e.printStackTrace();
	        }
	    }

}
