package ProjectJDBC;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class VoyageDAO {

    public void createVoyage(Voyage voyage) {

        String query =
        "INSERT INTO voyages(ship_id,source_port_id,destination_port_id,departure_time,arrival_time,cargo_weight,status) VALUES(?,?,?,?,?,?,?)";

        try(
            Connection con =
            DBConnection.getConnection();

            PreparedStatement ps =
            con.prepareStatement(query);
        ) {

            ps.setInt(1, voyage.getShipId());

            ps.setInt(2, voyage.getSourcePortId());

            ps.setInt(3, voyage.getDestinationPortId());

            ps.setTimestamp(4, voyage.getDepartureTime());

            ps.setTimestamp(5, voyage.getArrivalTime());

            ps.setDouble(6, voyage.getCargoWeight());

            ps.setString(7, voyage.getStatus());

            ps.executeUpdate();

            System.out.println(
            "Voyage Created Successfully"
            );

        } catch(Exception e) {

            e.printStackTrace();
        }
    }

    // VIEW VOYAGES WITH JOIN
    public void viewVoyages() {

        String query =
        "SELECT s.ship_name, " +
        "p1.port_name AS source_port, " +
        "p2.port_name AS destination_port, " +
        "v.cargo_weight, " +
        "v.status " +

        "FROM voyages v " +

        "JOIN ships s " +
        "ON v.ship_id = s.ship_id " +

        "JOIN ports p1 " +
        "ON v.source_port_id = p1.port_id " +

        "JOIN ports p2 " +
        "ON v.destination_port_id = p2.port_id";

        try(
            Connection con =
            DBConnection.getConnection();

            PreparedStatement ps =
            con.prepareStatement(query);

            ResultSet rs =
            ps.executeQuery();
        ) {

            while(rs.next()) {

                System.out.println(

                    "Ship : " +
                    rs.getString("ship_name") +

                    " | Source : " +
                    rs.getString("source_port") +

                    " | Destination : " +
                    rs.getString("destination_port") +

                    " | Cargo : " +
                    rs.getDouble("cargo_weight") +

                    " | Status : " +
                    rs.getString("status")
                );
            }

        } catch(Exception e) {

            e.printStackTrace();
        }
    }

}
