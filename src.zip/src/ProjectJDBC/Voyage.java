package ProjectJDBC;

import java.sql.Timestamp;

public class Voyage {

	 private int voyageId;

	    private int shipId;

	    private int sourcePortId;

	    private int destinationPortId;

	    private Timestamp departureTime;

	    private Timestamp arrivalTime;

	    private double cargoWeight;

	    private String status;

	    public int getVoyageId() {
	        return voyageId;
	    }

	    public void setVoyageId(int voyageId) {
	        this.voyageId = voyageId;
	    }

	    public int getShipId() {
	        return shipId;
	    }

	    public void setShipId(int shipId) {
	        this.shipId = shipId;
	    }

	    public int getSourcePortId() {
	        return sourcePortId;
	    }

	    public void setSourcePortId(int sourcePortId) {
	        this.sourcePortId = sourcePortId;
	    }

	    public int getDestinationPortId() {
	        return destinationPortId;
	    }

	    public void setDestinationPortId(int destinationPortId) {
	        this.destinationPortId = destinationPortId;
	    }

	    public Timestamp getDepartureTime() {
	        return departureTime;
	    }

	    public void setDepartureTime(Timestamp departureTime) {
	        this.departureTime = departureTime;
	    }

	    public Timestamp getArrivalTime() {
	        return arrivalTime;
	    }

	    public void setArrivalTime(Timestamp arrivalTime) {
	        this.arrivalTime = arrivalTime;
	    }

	    public double getCargoWeight() {
	        return cargoWeight;
	    }

	    public void setCargoWeight(double cargoWeight) {
	        this.cargoWeight = cargoWeight;
	    }

	    public String getStatus() {
	        return status;
	    }

	    public void setStatus(String status) {
	        this.status = status;
	    }
}
