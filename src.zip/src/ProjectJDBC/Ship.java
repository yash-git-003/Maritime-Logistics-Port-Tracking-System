package ProjectJDBC;

public class Ship {


    private int shipId;

    private String shipName;

    private String shipType;

    private int capacity;

    private String ownerCompany;

    private String status;

    // Getter for shipId
    public int getShipId() {
        return shipId;
    }

    // Setter for shipId
    public void setShipId(int shipId) {
        this.shipId = shipId;
    }

    // Getter for shipName
    public String getShipName() {
        return shipName;
    }

    // Setter for shipName
    public void setShipName(String shipName) {
        this.shipName = shipName;
    }

    // Getter for shipType
    public String getShipType() {
        return shipType;
    }

    // Setter for shipType
    public void setShipType(String shipType) {
        this.shipType = shipType;
    }

    // Getter for capacity
    public int getCapacity() {
        return capacity;
    }

    // Setter for capacity
    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    // Getter for ownerCompany
    public String getOwnerCompany() {
        return ownerCompany;
    }

    // Setter for ownerCompany
    public void setOwnerCompany(String ownerCompany) {
        this.ownerCompany = ownerCompany;
    }

    // Getter for status
    public String getStatus() {
        return status;
    }

    // Setter for status
    public void setStatus(String status) {
        this.status = status;
    }
}
